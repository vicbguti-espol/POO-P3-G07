package modelo;

public enum TipoEstudiante {
    PARTICIPANTE,
    APOYO
}
