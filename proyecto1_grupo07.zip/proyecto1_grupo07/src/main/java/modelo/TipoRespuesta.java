package modelo;

public enum TipoRespuesta {
    CORRECTA,
    INCORRECTA
}
