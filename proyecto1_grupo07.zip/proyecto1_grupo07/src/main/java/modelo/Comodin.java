package modelo;

public enum Comodin {
    CINCUENTA,
    COMPANERO,
    SALON
}
